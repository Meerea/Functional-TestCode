/*Pseudocode
Get the input array and integer value 'diff'
Then initialize 3 variables i,j,k =0 and count=0 to count no of triplets in array
Then traverse through length of array using for loop and check conditions using if & else
If condition true , increment count and increment i,j,k index values and if condition false , increment i,j,k
 */

/*Positive -nums1 = [0,1,4,6,7,10],int  diff = 3
Negative - nums2 = [0,1,4,6,7,10], int diff = 3
 */


//Tie complexity O(n^3)


package junitCodes;

import org.junit.jupiter.api.Test;

public class ArithmeticTriplet {
    @Test
    void test1() {
        int[] num1 = {0,1,4,6,7,10};
        int diff=3;
        arithmeticTriplets(num1, diff);
    }

    public int arithmeticTriplets(int[] nums, int diff) {
        int count = 0;
        for(int i = 0 ; i < nums.length -2 ; i++){
            for(int j = i+1; j < nums.length -1; j ++){
                for(int k = j+1; k < nums.length ; k ++){
                    if(nums[j] - nums[i] == diff && nums[k] - nums[j] == diff){
                        count++;
                    }
                }
            }
        }
        return count;
    }
}
