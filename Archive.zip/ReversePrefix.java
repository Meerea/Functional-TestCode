/*PseudoCode
Get the input String and character
Initialize variable locate=0 and using for loop traverse and get the character input 'ch' and store the index value
in locate
Then initialize new variable array to store result
Then revrese the segment of word using the length as locate
 */

/*Test data
Positive - String s1 = "abcdefd";
        char ch1= 'd';
 Negative - String s1 = "abcdefd";
        char ch1= '';
 */

//Time complexity O(n^3)



package junitCodes;

import org.junit.jupiter.api.Test;

public class ReversePrefix {
    @Test
    void test1() {
        String s1 = "abcdefd";
        char ch1= 'd';
        reversePrefix(s1,ch1);
    }

    @Test
    void test2(){
        String s2 = "xyxzxe";
          char ch2= 'z';
    reversePrefix(s2,ch2);
    }
        public String reversePrefix(String word, char ch) {
            char[] c = word.toCharArray();
            int locate = 0;
            for (int i = 0; i < word.length(); i++) {
                if (ch == c[i]) {
                    locate = i;
                    break;
                }
            }
            char[] res = new char[word.length()];
            for (int i = 0; i <= locate; i++) {
                res[i] = c[locate - i];
            }
            for (int i = locate + 1; i < word.length(); i++) {
                res[i] = c[i];
            }
            return String.valueOf(res);
        }
    }


