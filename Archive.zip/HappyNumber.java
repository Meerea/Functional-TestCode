
/*pseudocode
Initialize two variables fast ,slow to check condition of happy number
Then create a separate method to sum all conditon of squares of give input
then return the number
 */

/*Test data
Positive - int n=19
Negative int n=2
 */

//Time complexity O(n)

package junitCodes;

import org.junit.jupiter.api.Test;

public class HappyNumber {
    @Test
    void test1() {
        int n1 = 19;
        isHappy(n1);
    }

    @Test
    void test2() {
        int n2 = 0;
        isHappy(n2);
    }

    public boolean isHappy(int n) {
        int slow = n;
        int fast = n;
        do {
            slow = findSquare(slow);
            fast = findSquare(findSquare(fast));
        } while (slow != fast);

        if (slow == 1) {
            return true;
        }
        return false;
    }

    public int findSquare(int num) {
        int n = 0;
        while (num > 0) {
            int mod = num % 10;
            n += mod * mod;
            num /= 10;
        }
        return n;
    }

}