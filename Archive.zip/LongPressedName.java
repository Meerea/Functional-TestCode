
/*Pseudo code
Check the first,last character and length - Return false if it's not same
Iterate the name string and put it in hash map
Initialize 2 pointer starting 1st from 1st char of each string
If both chars are same , increment both pointers
If it's not same, check its if is same as the previous character - if not return false
Finally check if pointer in name string is greater than or equal to name string
 */
/*test data
Positive -  String name = "alex";
        String typed = "aaleex";
 Negative - String name="";
 */
//Time Complexity -O(n*n)



package junitCodes;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

public class LongPressedName {
    @Test
    void test1() {
        String name = "alex";
        String typed = "aaleex";
        isLongPressedName2(name,typed);
    }
    @Test
    void test2(){
        String name1="";
        String typed="ee";
        isLongPressedName2(name1,typed);
    }
    public boolean isLongPressedName2(String name, String typed) {
        if (typed.length() < name.length() || typed.charAt(typed.length() - 1) != name.charAt(name.length() - 1) ||
                name.charAt(0) != typed.charAt(0)) {
            return false;
        }
        Map<Integer,Character> map = new HashMap<>();
        int j = 0;
        for(int i = 0; i < name.length(); i++) {
            map.put(i,name.charAt(i));
        }

        for(int i = 0; i < typed.length(); i++) {
            char ch = typed.charAt(i);
            if(j < map.size() && ch == map.get(j)) {
                j++;
            } else if (ch != map.get(j - 1)) {
                return false;
            }
        }
        return j >= name.length();
    }

}

