
/*PseudoCode
Get the input arrays num1, num2 and sort both arrays
Initiate i=0,j=0 and using while loop traverse through 2 arrays until their length nums1 & num2
Initiate new arraylist variable and Check conditions using if nums1[i] == nums[j], if true store in arraylist variable
Check other conditions nums1[i]< nums[j],nums1[i]< nums2[j] using 'if else'
Initiate new output array and print the arraylist variable values in output array using 'for' loop
 */

/*Test data
Positive -nums1 = [1,2,2,1],nums2 = [2,2]
Negative -nums2 =[1,2,3,4],nums2[5,5]
 */


//Time complexity O(n*m)

package junitCodes;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class IntersectionOfTwoII {

    //Positive test
    @Test
    public void test1() {
        int[] array1 = {1, 2, 2, 1};
        int[] array2 = {2, 2};
        intersect(array1, array2);
    }

    //Negative test
    @Test
    public void test2() {
        int[] arr1 = {1, 2, 3, 4};
        int[] arr2 = {5, 5};
        intersect(arr1, arr2);
    }

    public int[] intersect(int[] nums1, int[] nums2) {

        int i = 0, j = 0;
        List<Integer> result = new ArrayList<Integer>();
        Arrays.sort(nums1);
        Arrays.sort(nums2);

        while (i < nums1.length && j < nums2.length) {
            if (nums1[i] == nums2[j]) {
                result.add(nums1[i]);
                i++;
                j++;
            } else if (nums1[i] < nums2[j]) {
                i++;
            } else if (nums1[i] > nums2[j]) {
                j++;
            }
        }
        int[] ans = new int[result.size()];
        for (i = 0; i < result.size(); i++) {
            ans[i] = result.get(i);
        }
        System.out.println("intersection"+ Arrays.toString(ans));
        return ans;

    }
}


