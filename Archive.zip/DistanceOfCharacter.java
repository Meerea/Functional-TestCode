/*Pseudocode
Initialize input String S and Character c. Then convert string S char[] array,integer variable eIndex and
initialize output array res[]
Traverse char[] using for loop (From start to middle or until find 'c')and check condition char[i]== c,
if true make eIndex==i
Use condition Math.min(eIndex - i, res[i])
Then Traverse from Last of char[] and check condition char[i]== c, if true make eIndex==i
Use condition res[i] = Math.min(eIndex - i, res[i]);
Then print 'res'

 */

/*Test data
Positive -s = "loveleetcode", c = "e"
 */


//Time Complexity O(n^2)


package junitCodes;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

public class DistanceOfCharacter {
    @Test
    void test1() {
        String s= "loveleetcode";
        char c = 'e';
        shortestToChar(s,c);
    }

    public static int[] shortestToChar(String S, char c) {

        char[] strch = S.toCharArray();
        int eIndex = Integer.MAX_VALUE;//MIN_VALUE
        int[] res = new int[strch.length];

        for (int i = 0; i < strch.length; i++) {
            if (strch[i] == c) {
                eIndex = i;
            }
            res[i] = Math.abs(i - eIndex);
        }
        //System.out.println(Arrays.toString(res));
        eIndex = Integer.MAX_VALUE;
        for (int i = strch.length - 1; i >= 0; i--) {
            if (strch[i] == c) {
                eIndex = i;
            }
            res[i] = Math.min(eIndex - i, res[i]);
        }
        System.out.println(Arrays.toString(res));
        return res;
    }

    public static void main(String[] args)
    {
        String S = "loveleetcode";
        char c = 'e';

        shortestToChar(S,c);
    }


}



