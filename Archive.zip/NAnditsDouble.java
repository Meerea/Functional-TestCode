

/*Pseudocode
Get input array arr and initialize nested 'for' loop with i=0 and j=0 and given condition i !=j
Then Check the condition any arr element meets arr[i]== 2* arr[j], if so return 'true' else 'false'

 */

/*Test Data
Positive arr={10,2,5,3}
Negative arr={3,1,7,11}
 */


//Time Complexity - O(n^2)



package junitCodes;

import org.junit.jupiter.api.Test;

public class NAnditsDouble {

    //Positive test
    @Test
    public void test1() {
        int[] arr1={10,2,5,3};
        checkIfExist(arr1);
    }
    //Negative test
    @Test
    public void test2() {
        int[] arr2 = {3, 1, 7, 11};
        checkIfExist(arr2);
    }
    public boolean checkIfExist(int[] arr) {
        for(int i=0; i<arr.length; i++){
            for(int j=0; j<arr.length; j++){
                if(arr[i]==2*arr[j]) {
                    System.out.println(arr[i] + arr[j]);

                }    return true;
            }

        }
        return false;
    }

}
