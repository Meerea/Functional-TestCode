
/*Pseudocode
Get input arrays nums1,nums2 and its int values m,n
Initialize two integer variables i=0,j=0
Check the length of nums1 equals m+n and nums1 index value of 'm' equals zero to take it as start point for the merge
Then merge the nums2 values in nums1 using while loop
 */

/* Test data
Positive - nums1 = [1,2,3,0,0,0], m = 3, nums2 = [2,5,6], n = 3
Negative - nums2 = nums1 = [1], m = 1, nums2 = [], n = 0

 */

//Time complexity O(n)

package junitCodes;

import org.junit.jupiter.api.Test;


import java.util.Arrays;

public class MergeSortedArray {

  //Positive Test
    @Test
    void test1() {
        int[] nums1 = {1,2,3,0,0,0};
        int[] nums2 = {2,5,6};
        int n=3;int m=3;
        merge(nums1,m,nums2,n);
    }

    @Test
    void test2() {
        int[] arr1 = {1};int m = 1;
        int[] arr2 = {}; int n = 0;
        merge(arr1,m,arr2,n);

    }

    public void merge(int[] nums1, int m, int[] nums2, int n) {
        int j=0;
         if(nums1.length== m+n){
            // if(nums1[m]==0){
                 while(m<nums1.length && j<nums2.length){
                     nums1[m++]=nums2[j++];
                 }
                 Arrays.sort(nums1);
             System.out.println("Merged Array" + Arrays.toString(nums1));
         }
         else{
             System.out.println("Merged array not possible");
         }
    }


}
