
/*PseudoCode
Get the input string sentence and segregate the words in to String[] using split method and condition as space
Initialize Result string to store reversed string
Then traverse through the length of sentence using for loop until string length
Convert string array to characters array and initiate first=0, last=length-1 of char array and temp=0
Using while loop traverse and swap first & last char of subarray and add the reversed word to res string
Then increment first++ and decrement last--

 */

/*Test Data
Positive - String s1="Let's take LeetCode contest";
Negative - String s1="L";

 */

//Time complexity - O(n^2)
package junitCodes;

import org.junit.jupiter.api.Test;

import static java.sql.Types.NULL;

public class ReverseWordsInSen{


  //Positive Test
    @Test
    void test1() {
        String s1="Let's take LeetCode contest";
        reverseWords(s1);
    }
    @Test
    void test2() {
        String s1 = "";
        reverseWords(s1);
    }

    public String reverseWords(String s) {
        String res="";
        if((s.length()!=NULL) && (s.length()!=2)) {
            String[] wordsArray = s.split(" ");

        for(int i=0;i<wordsArray.length;i++) {
            char[] c = wordsArray[i].toCharArray();
            int last=c.length-1; int first=0;

            while(first<last) {
                char temp = c[first];
                c[first] = c[last];
                c[last] = temp;
                last--;first++;
            }
            res += new String(c);
            if(i!=wordsArray.length-1) {
                res+=" ";
            }
        }
        System.out.println(" reversed String -"+" "+res);
    }
        else{
        System.out.println("String not eligible for reverese" + s);
        }
        return res;
    }

}



