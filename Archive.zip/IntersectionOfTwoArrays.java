/*Pseudocode
Initialize two input arrays num1,num2 and integer variable index=0,res=0 for using in iterations
Initialize Set and Initialize output array out[] with size of Set(Using Set's size method)
Traverse through nested for loop using one for num1 and one for num2
Check condition for intersection as if(num1[i]==num2[j]),then print that no in variable res and insert the
res value in Set
Then using For each loop iterate and print Set values in output array out[]
 */


/*Test data
Positive -nums1 = [1,2,2,1], nums2 = [2,2]
Negative -nums2 = [1,2,2,1], nums2 = [2,2]
 */

//Time Complexity O(n^2)

package junitCodes;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class IntersectionOfTwoArrays {
    @Test
    void test1() {
        int[] nums1 = {1,2,2,1};
        int[] nums2 = {2,2};
        intersectionArray(nums1,nums2);
    }
        public static int[] intersectionArray(int[] num1,int[] num2)
        {
            int index=0;int res=0;
            Set<Integer> resultSet = new HashSet<Integer>();

            for(int i=0;i<num1.length;i++) {
                for (int j = 0; j < num2.length; j++) {
                    if (num1[i] == num2[j]) {
                        res=num1[i];
                        resultSet.add(res);
                    }
                }
            }
            int[] out= new int[resultSet.size()];
            for(int val :resultSet) {
                out[index++] = val;
            }
            System.out.println("Insection Array"+" "+ Arrays.toString(out));
            return out;
        }
        public static void main(String[] args)
        {
            int[] set1={1,2,2,1,5};
            int[] set2={2,2};
            intersectionArray(set1,set2);
        }
    }





