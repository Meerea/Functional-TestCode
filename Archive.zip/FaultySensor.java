/*Pseudocode
Get the two array sensor values,and traverse through sensor1 & sensor2 values using 'for' loop
Initiate i=length-1, j=length-1 and check both values i!+j,if condition true,
Then check i=j's second last value and if its true - second sensor is fault
If the i!=j's second last , then check j-length value equals i's second last value, then 1 sensor is fault

 */

/*Test Data
Positive - sensor1 = [2,3,4,5], sensor2 = [2,1,3,4]
Negative - sensor1 = [2,3,4,5], sensor2 = [0,0,0]
 */

//Time complexity O(n)

package junitCodes;

import org.junit.jupiter.api.Test;

public class FaultySensor {

    //Positive test
    @Test
    public void test1() {
        int[] sensor1 = {2,3,2,2,3,2};
        int[] sensor2 = {2,3,2,3,2,7};
        faultySensor(sensor1,sensor2);
    }
//Positive test 2
    @Test
    public void test2() {
        int[] sensor1 = {2,3,4,5};
        int[] sensor2 = {2,1,3,4};
        faultySensor(sensor1,sensor2);
    }
   // Negative test
    @Test
    public void test3() {
        int[] sensor1 = {2,3,4,5,0};
        int[] sensor2 = {2,1,3,4};
        faultySensor(sensor1,sensor2);
    }


    public void faultySensor(int[] s1,int[] s2){
        int i=s1.length-1;
        int j=s2.length-1;
        if (s1.length==s2.length && s1[i]!=s2[j]){
            if(s1[i]==s2[j--]){
                System.out.println("Faulty sensor 2");
            }
            else if(s2[j]==s1[i--]){
                System.out.println("Faulty sensor 1");
            }
            else{
                System.out.println("Faulty sensor can't be detected -1");
            }


        }
        else{
            System.out.println("Sensor not equal in length");
        }
    }
}
