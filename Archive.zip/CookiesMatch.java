
/*Pseudocode
Get input of 2 arrays- g[] & s[] and initialize variables int i=0,j=o and count =0
Use While loop to check each element of both arrays as condition(i<g.length && j<s.length)
Then check condition of s[] index values equals or greater than g[] index values using if & else statements
On condition becomes true increment count++ and return count value

 */


/*Test Data
Positive g={1,2,3}, s={1,1}
Negative g={12},s={0,0}

 */

/*Time complexity -O(n) */

package junitCodes;

import org.junit.jupiter.api.Test;

public class CookiesMatch {

//Positive test
    @Test
    public void test1(){
        int[] g1={1,2,3};
        int[] s1={1,2};
        findContentChildren(g1,s1);
    }
//Negative test
    @Test
    public void test2(){
        int[] g1={1,2};
        int[] s1={0,0};
        findContentChildren(g1,s1);
    }
    public int findContentChildren(int[] g,int[] s) {
        int count =0;
        int i=0;
        int j=0;
        while(i<g.length && j<s.length){
           // for(int j=0;j<s.length;j++)
                if(g[i]==s[j] || g[i] < s[j]){
                    count++;
                }
                else if(g[i] == 0 || s[j]==0) {
                    //System.out.println("no cookies match");
                }


            i++;
            j++;
        }
        System.out.println("cookies match" + count);

        return count;
    }
}

