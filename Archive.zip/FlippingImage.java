/*Pseudocode
Initialize index values as left ,right and using while loop traverse through length
Then reverse the elements of image
 */

 /*Test data
   Positive -image[] = [[1,1,0],[1,0,1],[0,0,0]]
   Negative -image[] =[]
 */
//Time Complexity O(n^2)




package junitCodes;

import org.junit.jupiter.api.Test;

public class FlippingImage {


    @Test
    void name() {
    }


    public int[][] flipAndInvertImage(int[][] image) {
        for(int i=0; i<image.length; i++){
            int left=0, right=image.length-1;
            while(left<=right){
                int temp = image[i][left];
                image[i][left] = image[i][right];
                image[i][right] = temp;
                left++;right--;
            }
        }

        for(int i=0; i<image.length; i++){
            for(int j=0; j<image.length; j++){
                if(image[i][j]==0) image[i][j]=1;
                else image[i][j]=0;
            }
        }

        return image;

    }
}






