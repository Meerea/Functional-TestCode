/*Pseudocode
Get the input string and convert to character arrays
Initialize list character having vowels a,e,i,o,u of both upper & lower case
Initialize left =0, right =string.length-1 and character varialble temp
Then traverse through string and check condition that list contains any char in left & right
If condition equals , swap the first & left and increment both left & right
Then proceed with other conditions if only left has vowel , then increment left
And if right has only vowel increment right

 */


/*Test data
Positive - String s1="hello"
Negative - String s1="test"
 */

//Time complexity O(n)

package junitCodes;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

public class ReverseVowels{
    @Test
    void test1() {
        String s1="hello";
        reverseVowels(s1);
    }

    @Test
    void test2() {
        String s1="hello";
        reverseVowels(s1);
    }
        public String reverseVowels(String s) {
        List<Character> list= Arrays.asList('a', 'e', 'i','o','u','A','E','I','O','U');

            char[] arr= s.toCharArray();
            int left =0;int right=s.length()-1;

            while(left<right || left==right){
                if(list.contains(arr[left]) && list.contains(arr[right])){
                    char temp= arr[left];
                    arr[left]=arr[right];
                    arr[right]=temp;
                    left++;
                    right--;
                }
            else if(list.contains(arr[left]) && !list.contains(arr[right])){
                right--;
            }else if(!list.contains(arr[left]) && list.contains(arr[right])){
                left++;
            }else if(!list.contains(arr[left]) && !list.contains(arr[right])){
                left++;
                right--;
            }
        }
            String res= Arrays.toString(arr);
            System.out.println("characters" +" " +res);
            return res;
    }


}
